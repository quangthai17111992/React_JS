export const CHECK_AUTH_STAGE_CHANGED = 'CHECK_AUTH_STAGE_CHANGED'
export const LOG_IN = 'LOG_IN'
export const LOGGED = 'LOGGED'
export const LOG_OUT = 'LOG_OUT'
