import React from 'react'
import FromRegister from './FromRegister/FromRegister'

const Register = () => {
	return <FromRegister />
}

export default Register
