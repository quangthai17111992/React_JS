import React from 'react'
import FromLogin from './FromLogin/FromLogin'

const Login = () => {
	return <FromLogin />
}

export default Login
