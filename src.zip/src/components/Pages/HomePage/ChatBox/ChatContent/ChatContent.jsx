import React from 'react'
import PerfectScrollbar from 'react-perfect-scrollbar'

import Message from './Message/Message'

const ChatContent = () => {
	const chatContainerRef = React.createRef()

	const updateScrollbar = (container) => {
		if (container && container._container) {
			container._container.scrollTop = chatContainerRef.current.scrollHeight
			// đoạn nay _container không hiểu được
		}
	}

	return (
		<PerfectScrollbar ref={(container) => updateScrollbar(container)}>
			<div
				ref={chatContainerRef}
				className='chat-message-content overflow-hidden px-5 pt-5 flex-1 bg-white'
			>
				<Message isCurrentUser={false} />
				<div className='clear-both'></div>
				<Message isCurrentUser={true} />
				<Message isCurrentUser={false} />
				<div className='clear-both'></div>
				<Message isCurrentUser={true} />
				<Message isCurrentUser={false} />
				<div className='clear-both'></div>
				<Message isCurrentUser={true} />
				<Message isCurrentUser={false} />
				<div className='clear-both'></div>
				<Message isCurrentUser={true} />
				<Message isCurrentUser={false} />
				<div className='clear-both'></div>
				<Message isCurrentUser={true} />
				<Message isCurrentUser={false} />
				<div className='clear-both'></div>
				<Message isCurrentUser={true} />
			</div>
		</PerfectScrollbar>
	)
}

export default ChatContent
