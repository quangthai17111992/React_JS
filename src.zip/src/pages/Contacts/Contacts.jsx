import React from 'react'

const Contacts = () => {
	return <div>Contact page</div>
}

export default Contacts
