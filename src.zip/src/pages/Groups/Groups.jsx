import React from 'react'

const Groups = () => {
	return <div>Groups page</div>
}

export default Groups
